
/*
1. Java AWT (Abstract Window Toolkit), platform-dependent, i.e., components are displayed according to the view of OS.
    API: TextField, Lable, TextArea, RadioButton, CheckBox, Choice, List

    Object -> Component -> Button, Label, CheckBox, Choice, List, Container
        Container -> Window, Panel
            Window -> Frame, Dialog
            Panel -> Applet
 */

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import javax.swing.*;

public class HExpMetDB {

    public static void main(String[] args) {
        Index index = new Index();

        //"E:\\bio2\\HExpMetDB";
        index.load(".");
        index.draw(".");

        index.setVisible(true);
    }
}

class Index extends JFrame implements ActionListener {

    HashMap<String, HashSet<String>> inchiParentECbased = new HashMap<>(); //<InChI, Smile>
    HashMap<String, HashSet<String>> inchiParentCYP450 = new HashMap<>();
    HashMap<String, HashSet<String>> inchiParentPhaseII = new HashMap<>();
    HashMap<String, HashSet<String>> inchiParentHgut = new HashMap<>();

    HashMap<String, String[]> inchiInfo = new HashMap<>(); // <InChI, Info>
    HashMap<String, HashSet<String>> formulaMap2 = new HashMap<>(); //<Formula, InChI>
    TreeMap<Double, HashSet<String>> massMap2 = new TreeMap<>(); //<Mass, InChI>

    Container container;
    JComboBox type;
    String[] parent = {"CASRN", "Formula", "Mass"}, metabolite = {"Formula", "Mass"};
    JComboBox options, charge, adducts;
    JButton search;
    JTextField keyText, tolText;

    String[] posAdd = {"M+3H", "M+2H+Na", "M+H+2Na", "M+3Na", "M+2H", "M+H+NH4", "M+H+Na", "M+H+K", "M+ACN+2H", "M+2Na", "M+2ACN+2H", "M+3ACN+2H", "M+H",
            "M+NH4", "M+Na", "M+CH3OH+H", "M+K", "M+ACN+H", "M+2Na-H", "M+IsoProp+H", "M+ACN+Na", "M+2K-H", "M+DMSO+H", "M+2ACN+H", "M+IsoProp+Na+H",
            "2M+H", "2M+NH4", "2M+Na", "2M+K", "2M+ACN+H", "2M+ACN+Na"};

    String[] negAdd = {"M-3H", "M-2H", "M-H2O-H", "M-H", "M+Na-2H", "M+Cl", "M+K-2H", "M+FA-H", "M+Hac-H", "M+Br", "M+TFA-H", "2M-H", "2M+FA-H", "2M+Hac-H", "3M-H"};

    String[] display = {"ID", "CASRN", "DTXSID", "Name", "IUPAC NAME", "Molecular formula", "Averagre mass", "Monoisotopic mass", "HLB (h)", "SEEM3 (mg/kg-BW/day)",
            "SEEM3 95%CI", "Oral rat LD50 mol/kg", "Oral rat LD50 95%CI", "ToxCast number of active assay/total", "Toxpi", "ToxPi 95% CI", "PrRfD", "PrRfD 95%CI", "PrHQ", "PrHQ 95%CI",
            "PrHQ Rank", "RI", "RI 95%CI", "RI Rank", "SMILES", "QSAR ready SMILES", "InChI String", "InChIKey", "logKow", "logKoa"};
    JCheckBox[] displayBox;

    JPanel searchResult;
    JTable searchTable;
    JComboBox innerModes;
    JButton click;
    JScrollPane innerResult;

    String[][] matters = null;
    JScrollPane matterPanel;
    JTable matterTable;
    HashMap<String, Integer> casrnMap = new HashMap<>();
    HashMap<String, ArrayList<Integer>> formulaMap = new HashMap<>();
    TreeMap<Double, ArrayList<Integer>> massMap = new TreeMap<>();

    JComboBox modes;
    JButton predict;
    HashMap<String, ArrayList<String[]>> ecbased = new HashMap<>();
    HashMap<String, ArrayList<String[]>> cyp450 = new HashMap<>();
    HashMap<String, ArrayList<String[]>> phaseII = new HashMap<>();
    HashMap<String, ArrayList<String[]>> hgut = new HashMap<>();
    JPanel dbResult;

    JButton update;

    public Index() {
        setTitle("HExpMetDB");
        setBounds(0, 0, 1920, 1000);
        //setVisible(true);
        setLayout(null);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    public void load(String filePath){

        String sep = System.getProperty("os.name").toLowerCase().indexOf("win")>=0? "\\":"/";
        BufferedReader br;
        try {
            br = new BufferedReader(new FileReader(filePath+ sep + "ecbased_AB.txt"));
            String line;
            while ((line=br.readLine())!=null) {
                String smile = line;
                String[] fields;
                ArrayList<String[]> list = new ArrayList<>();
                br.readLine();
                while ((line = br.readLine()) != null) {
                    if (line.length() > 0) {
                        fields = line.split("\t");
                        if (fields.length == 15) list.add(fields);
                        else {
                            System.out.println("ecbased: " + line);
                        }
                        if(formulaMap2. containsKey(fields[0])) formulaMap2.get(fields[0]).add(fields[2]);
                        else {
                            HashSet<String> set = new HashSet<>(); set.add(fields[2]);
                            formulaMap2.put(fields[0], set);
                        }

                        if(fields[1].charAt(0)!='-'){
                            Double ma = Double.parseDouble(fields[1]);
                            if(massMap2.containsKey(ma)) massMap2.get(ma).add(fields[2]);
                            else {
                                HashSet<String> set = new HashSet<>(); set.add(fields[2]);
                                massMap2.put(ma, set);
                            }
                        }

                        if(!inchiInfo.containsKey(fields[2])) inchiInfo.put(fields[2], fields);

                        if(inchiParentECbased.containsKey(fields[2])) inchiParentECbased.get(fields[2]).add(smile);
                        else {
                            HashSet<String> set = new HashSet<>(); set.add(smile);
                            inchiParentECbased.put(fields[2], set);
                        }
                    } else break;
                }
                ecbased.put(smile, list);
            }
            br.close();

            br = new BufferedReader(new FileReader(filePath+ sep + "cyp450_AB.txt"));
            while ((line=br.readLine())!=null){
                String smile = line;
                String[] fields;
                ArrayList<String[]> list = new ArrayList<>();
                br.readLine();
                while ((line=br.readLine())!=null){
                    if(line.length()>0) {
                        fields = line.split("\t");
                        if(fields.length == 15) list.add(fields);
                        else System.out.println("cyp450: " + line);

                        if(formulaMap2. containsKey(fields[0])) formulaMap2.get(fields[0]).add(fields[2]);
                        else {
                            HashSet<String> set = new HashSet<>(); set.add(fields[2]);
                            formulaMap2.put(fields[0], set);
                        }

                        if(fields[1].charAt(0)!='-'){
                            Double ma = Double.parseDouble(fields[1]);
                            if(massMap2.containsKey(ma)) massMap2.get(ma).add(fields[2]);
                            else {
                                HashSet<String> set = new HashSet<>(); set.add(fields[2]);
                                massMap2.put(ma, set);
                            }
                        }

                        if(!inchiInfo.containsKey(fields[2])) inchiInfo.put(fields[2], fields);

                        if(inchiParentCYP450.containsKey(fields[2])) inchiParentCYP450.get(fields[2]).add(smile);
                        else {
                            HashSet<String> set = new HashSet<>(); set.add(smile);
                            inchiParentCYP450.put(fields[2], set);
                        }
                    }
                    else break;
                }
                cyp450.put(smile, list);
            }
            br.close();

            br = new BufferedReader(new FileReader(filePath+ sep +"phaseII_AB.txt"));
            while ((line=br.readLine())!=null){
                String smile = line;
                String[] fields;
                ArrayList<String[]> list = new ArrayList<>();
                br.readLine();
                while ((line=br.readLine())!=null){
                    if(line.length()>0) {
                        fields = line.split("\t");
                        if(fields.length == 15) list.add(fields);
                        else System.out.println("phaseII: " + line);

                        if(formulaMap2. containsKey(fields[0])) formulaMap2.get(fields[0]).add(fields[2]);
                        else {
                            HashSet<String> set = new HashSet<>(); set.add(fields[2]);
                            formulaMap2.put(fields[0], set);
                        }

                        if(fields[1].charAt(0)!='-'){
                            Double ma = Double.parseDouble(fields[1]);
                            if(massMap2.containsKey(ma)) massMap2.get(ma).add(fields[2]);
                            else {
                                HashSet<String> set = new HashSet<>(); set.add(fields[2]);
                                massMap2.put(ma, set);
                            }
                        }

                        if(!inchiInfo.containsKey(fields[2])) inchiInfo.put(fields[2], fields);

                        if(inchiParentPhaseII.containsKey(fields[2])) inchiParentPhaseII.get(fields[2]).add(smile);
                        else {
                            HashSet<String> set = new HashSet<>(); set.add(smile);
                            inchiParentPhaseII.put(fields[2], set);
                        }
                    }
                    else break;
                }
                phaseII.put(smile, list);
            }
            br.close();

            br = new BufferedReader(new FileReader(filePath+ sep + "hgut_AB.txt"));
            while ((line=br.readLine())!=null){
                String smile = line;
                String[] fields;
                ArrayList<String[]> list = new ArrayList<>();
                br.readLine();
                while ((line=br.readLine())!=null){
                    if(line.length()>0){
                        fields = line.split("\t");
                        if(fields.length == 15) list.add(fields);
                        else System.out.println("hgut: " + line);

                        if(formulaMap2. containsKey(fields[0])) formulaMap2.get(fields[0]).add(fields[2]);
                        else {
                            HashSet<String> set = new HashSet<>(); set.add(fields[2]);
                            formulaMap2.put(fields[0], set);
                        }

                        if(fields[1].charAt(0)!='-'){
                            Double ma = Double.parseDouble(fields[1]);
                            if(massMap2.containsKey(ma)) massMap2.get(ma).add(fields[2]);
                            else {
                                HashSet<String> set = new HashSet<>(); set.add(fields[2]);
                                massMap2.put(ma, set);
                            }
                        }

                        if(!inchiInfo.containsKey(fields[2])) inchiInfo.put(fields[2], fields);

                        if(inchiParentHgut.containsKey(fields[2])) inchiParentHgut.get(fields[2]).add(smile);
                        else {
                            HashSet<String> set = new HashSet<>(); set.add(smile);
                            inchiParentHgut.put(fields[2], set);
                        }
                    }
                    else break;
                }
                hgut.put(smile, list);
            }
            br.close();

        } catch (IOException e){
            e.printStackTrace();
        }
    }

    public double convertPos(String add, double mass){
        if(add.equalsIgnoreCase("M+3H")) return (mass - 1.007276) * 3;
        else if(add.equalsIgnoreCase("M+2H+Na")) return (mass - 8.334590) * 3;
        else if(add.equalsIgnoreCase("M+H+2Na")) return (mass - 15.7661904) * 3;
        else if(add.equalsIgnoreCase("M+3Na")) return (mass - 22.989218) * 3;
        else if(add.equalsIgnoreCase("M+2H")) return (mass - 1.007276) * 2;
        else if(add.equalsIgnoreCase("M+H+NH4")) return (mass - 9.520550) * 2;
        else if(add.equalsIgnoreCase("M+H+Na")) return (mass - 11.998247) * 2;
        else if(add.equalsIgnoreCase("M+H+K")) return (mass - 19.985217) * 2;
        else if(add.equalsIgnoreCase("M+ACN+2H")) return (mass - 21.520550) * 2;
        else if(add.equalsIgnoreCase("M+2Na")) return (mass - 22.989218) * 2;
        else if(add.equalsIgnoreCase("M+2ACN+2H")) return (mass - 42.033823) * 2;
        else if(add.equalsIgnoreCase("M+3ACN+2H")) return (mass - 62.547097) * 2;
        else if(add.equalsIgnoreCase("M+H")) return (mass - 1.007276);
        else if(add.equalsIgnoreCase("M+NH4")) return (mass - 18.033823);
        else if(add.equalsIgnoreCase("M+Na")) return (mass - 22.989218);
        else if(add.equalsIgnoreCase("M+CH3OH+H")) return (mass - 33.033489);
        else if(add.equalsIgnoreCase("M+K")) return (mass - 38.963158);
        else if(add.equalsIgnoreCase("M+ACN+H")) return (mass - 42.033823);
        else if(add.equalsIgnoreCase("M+2Na-H")) return (mass - 44.971160);
        else if(add.equalsIgnoreCase("M+IsoProp+H")) return (mass - 61.06534);
        else if(add.equalsIgnoreCase("M+ACN+Na")) return (mass - 64.015765);
        else if(add.equalsIgnoreCase("M+2K-H")) return (mass - 76.919040);
        else if(add.equalsIgnoreCase("M+DMSO+H")) return (mass - 79.02122);
        else if(add.equalsIgnoreCase("M+2ACN+H")) return (mass - 83.060370);
        else if(add.equalsIgnoreCase("M+IsoProp+Na+H")) return (mass - 84.05511);
        else if(add.equalsIgnoreCase("2M+H")) return (mass - 1.007276) / 2;
        else if(add.equalsIgnoreCase("2M+NH4")) return (mass - 18.033823) / 2;
        else if(add.equalsIgnoreCase("2M+Na")) return (mass - 22.989218) / 2;
        else if(add.equalsIgnoreCase("2M+K")) return (mass - 38.963158) / 2;
        else if(add.equalsIgnoreCase("2M+ACN+H")) return (mass - 42.033823) / 2;
        else if(add.equalsIgnoreCase("2M+ACN+Na")) return (mass - 64.015765) / 2;
        else return mass;
    }

    public double convertNeg(String add, double mass){
        if(add.equalsIgnoreCase("M-3H")) return (mass + 1.007276) * 3;
        else if(add.equalsIgnoreCase("M-2H")) return (mass + 1.007276) * 2;
        else if(add.equalsIgnoreCase("M-H2O-H")) return (mass + 19.01839);
        else if(add.equalsIgnoreCase("M-H")) return (mass + 1.007276);
        else if(add.equalsIgnoreCase("M+Na-2H")) return (mass - 20.974666);
        else if(add.equalsIgnoreCase("M+Cl")) return (mass - 34.969402);
        else if(add.equalsIgnoreCase("M+K-2H")) return (mass - 36.948606);
        else if(add.equalsIgnoreCase("M+FA-H")) return (mass - 44.998201);
        else if(add.equalsIgnoreCase("M+Hac-H")) return (mass - 59.013851);
        else if(add.equalsIgnoreCase("M+Br")) return (mass - 78.918885);
        else if(add.equalsIgnoreCase("M+TFA-H")) return (mass - 112.985586);
        else if(add.equalsIgnoreCase("2M-H")) return (mass + 1.007276) / 2;
        else if(add.equalsIgnoreCase("2M+FA-H")) return (mass - 44.998201) / 2;
        else if(add.equalsIgnoreCase("2M+Hac-H")) return (mass - 59.013851) / 2;
        else if(add.equalsIgnoreCase("3M-H")) return (mass + 1.007276) / 3;
        else return mass;
    }

    public void draw(String file){

        String sep = System.getProperty("os.name").toLowerCase().indexOf("win")>=0? "\\":"/";
        container = getContentPane();
        JTabbedPane tabbedPane = new JTabbedPane();
        JPanel p1 = new JPanel(), p2 = new JPanel();
        tabbedPane.add("Search", p1);
        tabbedPane.add("Database", p2);
        container.setBounds(0, 0, 1280, 720);
        tabbedPane.setBounds(0, 0, 1280, 650);
        p1.setBounds(0, 0, 1280, 650);
        p2.setBounds(0, 0, 1280, 650);
        tabbedPane.setVisible(true);
        p1.setVisible(true); //p2.setVisible(true);

        p1.setLayout(null);
        JPanel optionPanel = new JPanel();
        optionPanel.add(new JLabel("Select a Search Type: "));
        type = new JComboBox(new String[]{"Parent compound", "metabolite"}); type.setPreferredSize(new Dimension(150, 20));
        type.setSelectedIndex(-1);
        optionPanel.add(type);

        optionPanel.add(new JLabel("      Select a Input Type:"));
        options = new JComboBox(new String[]{"CASRN", "Formula", "Mass"}); options.setPreferredSize(new Dimension(100, 20));
        options.setSelectedIndex(-1);
        optionPanel.add(options); options.setEnabled(false);

        search = new JButton("Search"); search.addActionListener(this); search.setPreferredSize(new Dimension(80, 20));
        optionPanel.add(new JLabel("    "));
        keyText = new JTextField(20);
        optionPanel.add(keyText);
        optionPanel.add(new JLabel("           "));
        optionPanel.add(search);
        optionPanel.setBounds(10, 10, 1250, 25);
        p1.add(optionPanel);

        type.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent ie) {
                if(ie.getStateChange() == ItemEvent.SELECTED){
                    String item = (String)type.getSelectedItem();
                    if(item.equalsIgnoreCase("Parent compound")){
                        options.removeAllItems(); options.setEnabled(true);
                        for(String key: parent) options.addItem(key);
                        options.setSelectedIndex(-1);
                    }
                    else {
                        options.removeAllItems(); options.setEnabled(true);
                        for(String key: metabolite) options.addItem(key);
                        options.setSelectedIndex(-1);
                    }
                }
            }
        });

        options.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent ie) {
                //System.out.println("Event: " + ie.getStateChange());
                if(ie.getStateChange() == ItemEvent.SELECTED){
                    String item = (String)options.getSelectedItem();
                    if(item.equalsIgnoreCase("Mass")){
                        tolText.setEnabled(true); charge.setEnabled(true); adducts.setEnabled(true);
                    }
                    else {
                        tolText.setEnabled(false); charge.setEnabled(false); adducts.setEnabled(false);
                    }
                }
            }
        });

        JPanel massPanel = new JPanel();
        //massPanel.setLayout(new FlowLayout());
        massPanel.setBounds(10, 40, 1250, 25);
        massPanel.add(new JLabel("Tolerance"));
        tolText = new JTextField(8); tolText.setEnabled(false);
        massPanel.add(tolText);
        massPanel.add(new JLabel("    "));
        charge = new JComboBox(new String[]{"Neutral", "Positive", "Negative"}); charge.setPreferredSize(new Dimension(120, 20));
        charge.setSelectedIndex(-1);
        charge.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent ie){
                if(ie.getStateChange() == ItemEvent.SELECTED) {
                    String item = (String)charge.getSelectedItem();
                    if(item.equalsIgnoreCase("Neutral")) {
                        adducts.removeAllItems();
                        adducts.setEnabled(false);
                    }
                    else if(item.equalsIgnoreCase("Positive")){
                        adducts.removeAllItems();
                        adducts.setEnabled(true);
                        for(String key: posAdd) adducts.addItem(key);
                        adducts.setSelectedIndex(-1);
                    }
                    else {
                        adducts.removeAllItems();
                        adducts.setEnabled(true);
                        for(String key: negAdd) adducts.addItem(key);
                        adducts.setSelectedIndex(-1);
                    }
                }
            }
        });
        massPanel.add(new JLabel(" Charge"));
        massPanel.add(charge); charge.setEnabled(false);

        massPanel.add(new JLabel("      "));
        adducts = new JComboBox(); adducts.setPreferredSize(new Dimension(120, 20));
        for(String key: posAdd) adducts.addItem(key);
        adducts.setSelectedIndex(-1); adducts.setEnabled(false);
        massPanel.add(new JLabel("Adducts"));
        massPanel.add(adducts);
        p1.add(massPanel);

        searchResult = new JPanel();
        searchResult.setBounds(10, 70, 1250, 580);
        p1.add(searchResult);

        // p2 panel
        p2.setLayout(null);
        p2.add(new JLabel("Display")); p2.add(new JLabel("Options"));
//
        JPanel right = new JPanel();
        right.setBounds(5, 5, 1250, 100);

        displayBox = new JCheckBox[display.length];
        for(int x=0; x<display.length; x++) {
            String d = display[x];
            JCheckBox box = new JCheckBox(d, true); box.setVisible(true);
            displayBox[x] = box;
            right.add(box);
        }
        update = new JButton("Update"); update.addActionListener(this); update.setPreferredSize(new Dimension(80, 20));
        right.add(update);
        p2.add(right);

        matterPanel = new JScrollPane();
        matterPanel.setBounds(5, 110, 1250, 300);
        //matterPanel.setPreferredSize(new Dimension(1200, 400));
        String[] cols = null;
        ArrayList<String> row = new ArrayList<>();
        try {
            BufferedReader br = new BufferedReader(new FileReader(file+ sep +"total_matter.txt"));
            cols = br.readLine().split("\t");
            String line;
            while ((line = br.readLine())!=null){
                if(line.split("\t").length<10) {
                    line += br.readLine();
                }
                row.add(line);
            }
            br.close();
        } catch (IOException e){
            e.printStackTrace();
        }
        matters = new String[row.size()][];
        for(int i=0; i<matters.length; i++){
            matters[i] = row.get(i).split("\t");
            if(matters[i].length == 31) {
                String[] a = new String[30];
                for(int x=0; x<22; x++) a[x] = matters[i][x];
                a[22] = matters[i][22] + matters[i][23];
                for(int x=23; x<30; x++) a[x] = matters[i][x+1];
                matters[i] = a;
            }
            if(matters[i].length!=30) {
                System.out.println("row " + i + ": #(field) = " + matters[i].length);
                for(int f=0; f<matters[i].length; f++) {
                    System.out.println("field " + f + ": " + matters[i][f]);
                }
            }
            if(matters[i][1].indexOf('/')>=0) {
                String[] arr = matters[i][1].split("/");
                for(String a: arr) casrnMap.put(a, i);
            }
            else {
                casrnMap.put(matters[i][1], i);
            }

            if(formulaMap.containsKey(matters[i][5])) formulaMap.get(matters[i][5]).add(i);
            else {
                ArrayList<Integer> l = new ArrayList<>();
                l.add(i);
                formulaMap.put(matters[i][5], l);
            }
            //System.out.println("row " + i + ": mono mass = " + matters[i][7]);
            if(matters[i][7].charAt(0)=='-') continue;

            Double m = Double.parseDouble(matters[i][7]);
            if(massMap.containsKey(m)) massMap.get(m).add(i);
            else {
                ArrayList<Integer> l = new ArrayList<>();
                l.add(i);
                massMap.put(m, l);
            }
            //smileIndex.put(rows[i][8], rows[i][3]);
        }
        matterTable = new JTable(matters, cols);
        matterTable.getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        matterTable.setDefaultEditor(Object.class, null); // read-only table
        matterPanel.setViewportView(matterTable);
        p2.add(matterPanel);

        JPanel predictPanel = new JPanel(); predictPanel.setBounds(10, 415, 1250, 25);
        modes = new JComboBox(new String[]{"EC-based", "CYP450", "PhaseII", "HGUT"}); modes.setPreferredSize(new Dimension(120, 20));
        modes.setSelectedIndex(-1);
        predict = new JButton("Predict"); predict.addActionListener(this); predict.setPreferredSize(new Dimension(80, 20));
        predictPanel.add(new JLabel("Select a Metabolic Transformation: "));
        predictPanel.add(modes); predictPanel.add(new JLabel("     ")); predictPanel.add(predict);
        p2.add(predictPanel);

        dbResult = new JPanel();
        dbResult.setBounds(10, 445, 1250, 195);
        p2.add(dbResult);
        container.add(tabbedPane);

        //JPanel panel = new JPanel(); panel.setLayout(null);
        ImageIcon imageIcon = new ImageIcon(file + sep + "copyright.png");
        Image image = imageIcon.getImage().getScaledInstance(153, 133, Image.SCALE_SMOOTH);
        JLabel label = new JLabel(new ImageIcon(image));
        label.setBounds(580, 660, 153, 133);
        container.add(label);
    }

    @Override
    public void actionPerformed(ActionEvent ae){
        String action = ae.getActionCommand();
        if(action.equalsIgnoreCase("Search")){
            if(type.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(container, "Choose one type of chemicals", "Warning", JOptionPane.WARNING_MESSAGE);
            }
            else {
                String typeStr = (String)type.getSelectedItem();
                if(options.getSelectedItem() == null){
                    JOptionPane.showMessageDialog(container, "Choose one method for search", "Warning", JOptionPane.WARNING_MESSAGE);
                }
                else {
                    String optStr = (String)options.getSelectedItem();
                    ArrayList<Object> rows = null;
                    if(optStr.equalsIgnoreCase("CASRN")){
                        String casrn = keyText.getText();
                        if(!casrnMap.containsKey(casrn)){
                            searchResult.removeAll(); searchResult.revalidate(); searchResult.repaint();
                            JOptionPane.showMessageDialog(container, "No results are found", "Warning", JOptionPane.WARNING_MESSAGE);
                        }
                        else {
                            rows = new ArrayList<>(); rows.add(casrnMap.get(casrn));
                        }
                    }
                    else if(optStr.equalsIgnoreCase("Formula")){
                        String formula = keyText.getText();
                        if(typeStr.equalsIgnoreCase("Parent compound")){
                            if(!formulaMap.containsKey(formula)){
                                searchResult.removeAll(); searchResult.revalidate();; searchResult.repaint();
                                JOptionPane.showMessageDialog(container, "No results are found", "Warning", JOptionPane.WARNING_MESSAGE);
                            }
                            else {
                                rows = new ArrayList<>(); rows.addAll(formulaMap.get(formula));
                            }
                        }
                        else {
                            if(!formulaMap2.containsKey(formula)){
                                searchResult.removeAll(); searchResult.revalidate();; searchResult.repaint();
                                JOptionPane.showMessageDialog(container, "No results are found", "Warning", JOptionPane.WARNING_MESSAGE);
                            }
                            else {
                                rows = new ArrayList<>(); rows.addAll(formulaMap2.get(formula));
                            }
                        }
                    }
                    else if(optStr.equalsIgnoreCase("Mass")){
                        Double ma = 0.0, tol = 0.0;
                        try {
                            ma = Double.parseDouble(keyText.getText());
                            tol = Double.parseDouble(tolText.getText());
                            double min = ma - ma  * tol / 1.0e6, max = ma + ma * tol / 1.0e6;
                            if(charge.getSelectedItem() == null) {
                                JOptionPane.showMessageDialog(container, "Please select one charge method", "Warning", JOptionPane.WARNING_MESSAGE);
                            }
                            else {
                                String chg = (String) charge.getSelectedItem();
                                if(chg.equalsIgnoreCase("Neutral")){
                                    rows = new ArrayList<>();
                                    if(typeStr.equalsIgnoreCase("Parent compound")){
                                        for(Double m: massMap.subMap(min, true, max, true).keySet()){
                                            rows.addAll(massMap.get(m));
                                        }
                                    }
                                    else {
                                        for(Double m: massMap2.subMap(min, true, max, true).keySet()){
                                            rows.addAll(massMap2.get(m));
                                        }
                                    }
                                }
                                else {
                                    if(adducts.getSelectedItem() == null){
                                        JOptionPane.showMessageDialog(container, "Please select one adducts", "Warning", JOptionPane.WARNING_MESSAGE);
                                    }
                                    else {
                                        String adt = (String)adducts.getSelectedItem();
                                        if(chg.equalsIgnoreCase("Positive")){
                                            min = convertPos(adt, min); max = convertPos(adt, max);
                                        }
                                        else {
                                            min = convertNeg(adt, min); max = convertNeg(adt, max);
                                        }
                                        rows = new ArrayList<>();
                                        if(typeStr.equalsIgnoreCase("Parent compound")){
                                            for(Double m: massMap.subMap(min, true, max, true).keySet()){
                                                rows.addAll(massMap.get(m));
                                            }
                                        }
                                        else {
                                            for(Double m: massMap2.subMap(min, true, max, true).keySet()){
                                                rows.addAll(massMap2.get(m));
                                            }
                                        }
                                    }
                                }
                            }
                        } catch (NumberFormatException e){
                            JOptionPane.showMessageDialog(container, "Invalid input format", "Warning", JOptionPane.WARNING_MESSAGE);
                        }
                    }
                    if(rows != null) {
                        if(rows.size() > 0) {
                            if(typeStr.equalsIgnoreCase("Parent compound")){
                                //String[] col = new String[]{"CASRN", "Name", "Molecular formula", "Average mass",
                                //        "Monoisotopic mass", "HLB(h)", "ExpoCast median exposure prediction mg/kg-BW/day",
                                //        "Oral rat LD50 mol/kg",	"ToxCast number of active assay/total", "DTXSID", "QSAR ready SMILES", "InChI String"};

                                String[][] rows2 = new String[rows.size()][];
                                for(int i=0; i<rows.size(); i++){
                                    rows2[i] = matters[(Integer)rows.get(i)];
                                }
                                searchResult.removeAll();
                                searchTable = new JTable(rows2, display);
                                searchTable.getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                                searchTable.setDefaultEditor(Object.class, null);
                                JScrollPane resultPanel = new JScrollPane(); resultPanel.setVisible(true);
                                resultPanel.setViewportView(searchTable); resultPanel.setPreferredSize(new Dimension(1250, 300));

                                searchResult.add(resultPanel);
                                JPanel innerPanel = new JPanel();
                                innerModes = new JComboBox(new String[]{"EC-based", "CYP450", "PhaseII", "HGUT"});
                                innerModes.setPreferredSize(new Dimension(120, 20));
                                innerModes.setSelectedIndex(-1);
                                click = new JButton("Click"); click.addActionListener(this); click.setPreferredSize(new Dimension(80, 20));
                                innerPanel.add(new JLabel("Select a Metabolic Transformation: "));
                                innerPanel.add(innerModes); innerPanel.add(new JLabel("     ")); innerPanel.add(click);
                                searchResult.add(innerPanel);

                                innerResult = new JScrollPane(); innerResult.setPreferredSize(new Dimension(1250, 180));
                                innerResult.setVisible(false);
                                searchResult.add(innerResult);
                                searchResult.revalidate(); searchResult.repaint();
                            }
                            else {
                                String[] col = new String[]{"Molecular_formula", "Major_Isotope_Mass", "InChI", "Synonyms",
                                        "InChIKey", "ALogP", "Precursor_ID", "Precursor_InChI", "Precursor_InChIKey", "Precursor_ALogP",
                                        "Reaction", "Reaction_ID", "Metabolite_ID", "Enzyme(s)", "Biosystem", "Source"};
                                ArrayList<String[]> results2 = new ArrayList<>();
                                for(Object obj: rows){
                                    String chi = (String)obj;
                                    String[] info = inchiInfo.get(chi);
                                    if(inchiParentECbased.containsKey(chi)){
                                        for(String smile: inchiParentECbased.get(chi)){
                                            String[] fields = new String[col.length];
                                            for(int i=0; i<info.length; i++) fields[i] = info[i];
                                            fields[col.length-1] = "ECbased: " + smile;
                                            results2.add(fields);
                                        }
                                    }
                                    if(inchiParentCYP450.containsKey(chi)){
                                        for(String smile: inchiParentCYP450.get(chi)){
                                            String[] fields = new String[col.length];
                                            for(int i=0; i<info.length; i++) fields[i] = info[i];
                                            fields[col.length-1] = "CYP450: " + smile;
                                            results2.add(fields);
                                        }
                                    }
                                    if(inchiParentPhaseII.containsKey(chi)){
                                        for(String smile: inchiParentPhaseII.get(chi)){
                                            String[] fields = new String[col.length];
                                            for(int i=0; i<info.length; i++) fields[i] = info[i];
                                            fields[col.length-1] = "PhaseII: " + smile;
                                            results2.add(fields);
                                        }
                                    }
                                    if(inchiParentHgut.containsKey(chi)){
                                        for(String smile: inchiParentHgut.get(chi)){
                                            String[] fields = new String[col.length];
                                            for(int i=0; i<info.length; i++) fields[i] = info[i];
                                            fields[col.length-1] = "Hgut: " + smile;
                                            results2.add(fields);
                                        }
                                    }
                                }
                                String[][] rows2 = new String[results2.size()][];
                                for(int i=0; i<rows2.length; i++) rows2[i] = results2.get(i);

                                searchTable = new JTable(rows2, col);
                                searchTable.getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                                searchTable.setDefaultEditor(Object.class, null);
                                JScrollPane resultPanel = new JScrollPane(); resultPanel.setVisible(true);
                                resultPanel.setViewportView(searchTable); resultPanel.setPreferredSize(new Dimension(1250, 550));

                                searchResult.removeAll();
                                searchResult.add(resultPanel);
                                searchResult.add(new JLabel("Result: " + (rows2.length) + "records"));
                                searchResult.revalidate(); searchResult.repaint();
                            }
                        }
                        else {
                            searchResult.removeAll(); searchResult.revalidate(); searchResult.repaint();
                            JOptionPane.showMessageDialog(container, "No results are found", "Warning", JOptionPane.WARNING_MESSAGE);
                        }
                    }

                }
            }
        }
        else if(action.equalsIgnoreCase("Click")){
            int[] row = searchTable.getSelectedRows();
            String mode = (String)innerModes.getSelectedItem();
            if(row.length!=1 || mode == null){
                JOptionPane.showMessageDialog(container, "Select a chemical and a transformation method", "Warning", JOptionPane.WARNING_MESSAGE);
            }
            else {
                String smile = (String)searchTable.getModel().getValueAt(row[0], 25);
                ArrayList<String[]> list = null;
                if(mode.equalsIgnoreCase("EC-based")) list = ecbased.getOrDefault(smile, null);
                else if(mode.equalsIgnoreCase("CYP450")) list = cyp450.getOrDefault(smile, null);
                else if(mode.equalsIgnoreCase("PhaseII")) list = phaseII.getOrDefault(smile, null);
                else list = hgut.getOrDefault(smile, null);

                if(list == null) {
                    JOptionPane.showMessageDialog(container, "No results are found", "Warning", JOptionPane.WARNING_MESSAGE);
                }
                else {
                    String[] col = new String[]{"Molecular_formula", "Major_Isotope_Mass", "InChI",
                            "Synonyms", "InChIKey", "ALogP",
                            "Precursor_ID", "Precursor_InChI", "Precursor_InChIKey",
                            "Precursor_ALogP", "Reaction", "Reaction_ID",
                            "Metabolite_ID", "Enzyme(s)", "Biosystem"};
                    String[][] rows = new String[list.size()][];
                    for(int i=0; i<rows.length; i++){
                        rows[i] = list.get(i);
                    }
                    JTable resultTable = new JTable(rows, col);
                    //resultTable.getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                    resultTable.setDefaultEditor(Object.class, null);

                    innerResult.setViewportView(resultTable);
                    innerResult.setVisible(true);

                    searchResult.revalidate();
                    searchResult.repaint();
                }
            }
        }
        else if(action.equalsIgnoreCase("Predict")){
            int[] row = matterTable.getSelectedRows();
            String mode = (String)modes.getSelectedItem();
            if(row.length != 1 || mode == null){
                JOptionPane.showMessageDialog(container, "Select a chemical and a prediction method", "Warning", JOptionPane.WARNING_MESSAGE);
            }
            else {
                //String smile = (String)matterTable.getModel().getValueAt(row[0], 25);
                String smile = matters[row[0]][25];
                ArrayList<String[]> list = null;
                if(mode.equalsIgnoreCase("EC-based")){
                    //JOptionPane.showMessageDialog(container, "EC-based");
                    list = ecbased.getOrDefault(smile, null);
                }
                else if(mode.equalsIgnoreCase("CYP450")){
                    //JOptionPane.showMessageDialog(container, "CYP450");
                    list = cyp450.getOrDefault(smile, null);
                }
                else if(mode.equalsIgnoreCase("PhaseII")){
                    //JOptionPane.showMessageDialog(container, "PhaseII");
                    list = phaseII.getOrDefault(smile, null);
                }
                else{
                    //JOptionPane.showMessageDialog(container, "HGUT");
                    list = hgut.getOrDefault(smile, null);
                }
                if(list == null) {
                    JOptionPane.showMessageDialog(container, "No results are found", "Warning", JOptionPane.WARNING_MESSAGE);
                }
                else {
                    String[] col = new String[]{"Molecular_formula", "Major_Isotope_Mass", "InChI",
                            "Synonyms", "InChIKey", "ALogP",
                            "Precursor_ID", "Precursor_InChI", "Precursor_InChIKey",
                            "Precursor_ALogP", "Reaction", "Reaction_ID",
                            "Metabolite_ID", "Enzyme(s)", "Biosystem"};
                    String[][] rows = new String[list.size()][];
                    for(int i=0; i<rows.length; i++){
                        rows[i] = list.get(i);
                    }
                    JTable resultTable = new JTable(rows, col);
                    resultTable.getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                    resultTable.setDefaultEditor(Object.class, null);

                    JScrollPane resultPanel = new JScrollPane();
                    resultPanel.setVisible(true);
                    resultPanel.setViewportView(resultTable); resultPanel.setPreferredSize(new Dimension(1250, 150));

                    dbResult.removeAll();
                    dbResult.add(resultPanel);
                    JLabel label = new JLabel("Results: " + (rows.length) + " records"); label.setPreferredSize(new Dimension(200, 20));
                    dbResult.add(label);
                    dbResult.revalidate();
                    dbResult.repaint();
                }
            }
        }
        else if(action.equalsIgnoreCase("Update")) {
            ArrayList<String>[] arr = new ArrayList[matters.length];
            for(int x=0; x<arr.length; x++) arr[x] = new ArrayList<>();

            ArrayList<String> col = new ArrayList<>();
            for(int x=0; x<displayBox.length; x++) {
                if(displayBox[x].isSelected()) {
                    col.add(display[x]);
                    for(int m=0; m<arr.length; m++) arr[m].add(matters[m][x]);
                }
            }

            String[] col2 = new String[col.size()];
            String[][] matter2 = new String[matters.length][col.size()];
            for(int i=0; i<col.size(); i++) {
                col2[i] = col.get(i);
                for(int j=0; j<matters.length; j++) {
                    matter2[j][i] = arr[j].get(i);
                }
            }
            matterTable = new JTable(matter2, col2);
            matterTable.getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            matterTable.setDefaultEditor(Object.class, null); // read-only table

//            matterPanel.removeAll();
            matterPanel.setViewportView(matterTable);
            matterPanel.revalidate();
            matterPanel.repaint();


        }

    }

    public String[] parse(String line){
        ArrayList<String> ret = new ArrayList<>();
        int pre = 0, cur = 0;
        int n = line.length();
        while (cur < n){
            char ch = line.charAt(cur);
            if(ch=='"'){
                int next = line.indexOf('"', cur+1);
                ret.add(line.substring(cur+1, next));
                pre = next+2;
                cur = pre;
            }
            else if(ch==','){
                ret.add(line.substring(pre, cur));
                pre = cur+1;
                cur = pre;
            }
            else cur++;
        }
        ret.add(line.substring(pre, cur));
        String[] ret2 = new String[ret.size()];
        for(int i=0; i<ret2.length; i++) ret2[i] = ret.get(i);
        return ret2;
    }

}
